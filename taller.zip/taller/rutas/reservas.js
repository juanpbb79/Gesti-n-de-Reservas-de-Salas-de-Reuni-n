const express = require('express');
const router = express.Router();

let reservas = [];
let reservaIdCounter = 1;

function haySolapamiento(nuevaReserva, reservasExistentes) {
  return reservasExistentes.some(reserva => 
    reserva.salaId === nuevaReserva.salaId &&
    nuevaReserva.fechaHoraInicio < reserva.fechaHoraFin &&
    nuevaReserva.fechaHoraFin > reserva.fechaHoraInicio
  );
}

router.get('/', (req, res) => {
  res.json(reservas);
});

router.post('/', (req, res) => {
  const { salaId, nombreReservante, fechaHoraInicio, fechaHoraFin } = req.body;
  
  const sala = req.app.locals.salas.find(s => s.id === parseInt(salaId));
  if (!sala || sala.estado !== 'activo') {
    return res.status(400).json({ mensaje: 'La sala no está activa o no existe' });
  }

  const nuevaReserva = {
    id: reservaIdCounter++,
    salaId: parseInt(salaId),
    nombreReservante,
    fechaHoraInicio: new Date(fechaHoraInicio),
    fechaHoraFin: new Date(fechaHoraFin)
  };

  if (haySolapamiento(nuevaReserva, reservas)) {
    return res.status(400).json({ mensaje: 'La reserva se solapa con otra existente' });
  }

  reservas.push(nuevaReserva);
  res.status(201).json(nuevaReserva);
});

router.delete('/:id', (req, res) => {
  const { id } = req.params;
  const index = reservas.findIndex(r => r.id === parseInt(id));
  if (index === -1) {
    return res.status(404).json({ mensaje: 'Reserva no encontrada' });
  }
  reservas.splice(index, 1);
  res.status(204).send();
});

module.exports = router;

