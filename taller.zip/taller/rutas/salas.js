const express = require('express');
const router = express.Router();

let salas = [];
let salaIdCounter = 1;

router.get('/', (req, res) => {
  res.json(salas);
});

router.post('/', (req, res) => {
  const { nombre, capacidad } = req.body;
  const nuevaSala = {
    id: salaIdCounter++,
    nombre,
    capacidad,
    estado: 'activo'
  };
  salas.push(nuevaSala);
  res.status(201).json(nuevaSala);
});

router.put('/:id', (req, res) => {
  const { id } = req.params;
  const { nombre, capacidad, estado } = req.body;
  const sala = salas.find(s => s.id === parseInt(id));
  if (!sala) {
    return res.status(404).json({ mensaje: 'Sala no encontrada' });
  }
  Object.assign(sala, { nombre, capacidad, estado });
  res.json(sala);
});

router.delete('/:id', (req, res) => {
  const { id } = req.params;
  const index = salas.findIndex(s => s.id === parseInt(id));
  if (index === -1) {
    return res.status(404).json({ mensaje: 'Sala no encontrada' });
  }
  salas.splice(index, 1);
  res.status(204).send();
});

module.exports = router;

