import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [rooms, setRooms] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [newRoom, setNewRoom] = useState({ name: '', capacity: '' });
  const [newBooking, setNewBooking] = useState({ roomId: '', date: '', time: '' });

  useEffect(() => {
    fetchRooms();
    fetchBookings();
  }, []);

  const fetchRooms = async () => {
    const response = await axios.get('http://localhost:5000/api/rooms');
    setRooms(response.data);
  };

  const fetchBookings = async () => {
    const response = await axios.get('http://localhost:5000/api/bookings');
    setBookings(response.data);
  };

  const handleAddRoom = async (e) => {
    e.preventDefault();
    await axios.post('http://localhost:5000/api/rooms', newRoom);
    setNewRoom({ name: '', capacity: '' });
    fetchRooms();
  };

  const handleAddBooking = async (e) => {
    e.preventDefault();
    await axios.post('http://localhost:5000/api/bookings', newBooking);
    setNewBooking({ roomId: '', date: '', time: '' });
    fetchBookings();
  };

  return (
    <div className="App">
      <h1>Reserva de Salas de Reuniones</h1>
      
      <h2>Salas Disponibles</h2>
      <ul>
        {rooms.map((room, index) => (
          <li key={index}>{room.name} - Capacidad: {room.capacity}</li>
        ))}
      </ul>

      <h2>Agregar Nueva Sala</h2>
      <form onSubmit={handleAddRoom}>
        <input
          type="text"
          placeholder="Nombre de la sala"
          value={newRoom.name}
          onChange={(e) => setNewRoom({ ...newRoom, name: e.target.value })}
        />
        <input
          type="number"
          placeholder="Capacidad"
          value={newRoom.capacity}
          onChange={(e) => setNewRoom({ ...newRoom, capacity: e.target.value })}
        />
        <button type="submit">Agregar Sala</button>
      </form>

      <h2>Reservas Actuales</h2>
      <ul>
        {bookings.map((booking, index) => (
          <li key={index}>Sala: {booking.roomId}, Fecha: {booking.date}, Hora: {booking.time}</li>
        ))}
      </ul>

      <h2>Hacer una Reserva</h2>
      <form onSubmit={handleAddBooking}>
        <select
          value={newBooking.roomId}
          onChange={(e) => setNewBooking({ ...newBooking, roomId: e.target.value })}
        >
          <option value="">Selecciona una sala</option>
          {rooms.map((room, index) => (
            <option key={index} value={room.name}>{room.name}</option>
          ))}
        </select>
        <input
          type="date"
          value={newBooking.date}
          onChange={(e) => setNewBooking({ ...newBooking, date: e.target.value })}
        />
        <input
          type="time"
          value={newBooking.time}
          onChange={(e) => setNewBooking({ ...newBooking, time: e.target.value })}
        />
        <button type="submit">Hacer Reserva</button>
      </form>
    </div>
  );
}

export default App;

