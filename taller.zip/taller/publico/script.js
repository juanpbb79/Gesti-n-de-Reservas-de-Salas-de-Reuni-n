document.addEventListener('DOMContentLoaded', () => {
    const formSala = document.getElementById('formSala');
    const formReserva = document.getElementById('formReserva');
    const listaSalas = document.getElementById('listaSalas');
    const listaReservas = document.getElementById('listaReservas');
    const salaIdSelect = document.getElementById('salaId');
    const mensajeError = document.getElementById('mensajeError');

    cargarSalas();
    cargarReservas();

    formSala.addEventListener('submit', agregarSala);
    formReserva.addEventListener('submit', hacerReserva);

    async function cargarSalas() {
        try {
            const response = await fetch('/salas');
            const salas = await response.json();
            listaSalas.innerHTML = '';
            salaIdSelect.innerHTML = '<option value="">Seleccione una sala</option>';
            salas.forEach(sala => {
                listaSalas.innerHTML += `<li>${sala.nombre} - Capacidad: ${sala.capacidad}</li>`;
                salaIdSelect.innerHTML += `<option value="${sala.id}">${sala.nombre}</option>`;
            });
        } catch (error) {
            mostrarError('Error al cargar las salas');
        }
    }

    async function cargarReservas() {
        try {
            const response = await fetch('/reservas');
            const reservas = await response.json();
            listaReservas.innerHTML = '';
            reservas.forEach(reserva => {
                listaReservas.innerHTML += `<li>Sala: ${reserva.salaId} - ${reserva.nombreReservante} - Inicio: ${new Date(reserva.fechaHoraInicio).toLocaleString()} - Fin: ${new Date(reserva.fechaHoraFin).toLocaleString()}</li>`;
            });
        } catch (error) {
            mostrarError('Error al cargar las reservas');
        }
    }

    async function agregarSala(e) {
        e.preventDefault();
        const nombre = document.getElementById('nombreSala').value;
        const capacidad = document.getElementById('capacidadSala').value;
        try {
            const response = await fetch('/salas', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ nombre, capacidad }),
            });
            if (!response.ok) throw new Error('Error al agregar la sala');
            formSala.reset();
            cargarSalas();
        } catch (error) {
            mostrarError(error.message);
        }
    }

    async function hacerReserva(e) {
        e.preventDefault();
        const salaId = document.getElementById('salaId').value;
        const nombreReservante = document.getElementById('nombreReservante').value;
        const fechaHoraInicio = document.getElementById('fechaHoraInicio').value;
        const fechaHoraFin = document.getElementById('fechaHoraFin').value;

        if (new Date(fechaHoraInicio) >= new Date(fechaHoraFin)) {
            mostrarError('La fecha y hora de inicio debe ser anterior a la fecha y hora de fin');
            return;
        }

        try {
            const response = await fetch('/reservas', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ salaId, nombreReservante, fechaHoraInicio, fechaHoraFin }),
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.mensaje || 'Error al hacer la reserva');
            }
            formReserva.reset();
            cargarReservas();
        } catch (error) {
            mostrarError(error.message);
        }
    }

    function mostrarError(mensaje) {
        mensajeError.textContent = mensaje;
        setTimeout(() => mensajeError.textContent = '', 5000);
    }
});

